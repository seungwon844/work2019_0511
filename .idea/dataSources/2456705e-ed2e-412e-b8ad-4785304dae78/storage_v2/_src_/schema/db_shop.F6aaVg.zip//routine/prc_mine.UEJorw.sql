CREATE PROCEDURE prc_mine()
  begin 
	select * from tbl_member where name = '토마스';
	select * from tbl_product where name = '냉장고';
End;

