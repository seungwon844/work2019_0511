CREATE VIEW vw_member AS
  SELECT
    `db_shop`.`tbl_member`.`name`    AS `name`,
    `db_shop`.`tbl_member`.`address` AS `address`
  FROM `db_shop`.`tbl_member`;

