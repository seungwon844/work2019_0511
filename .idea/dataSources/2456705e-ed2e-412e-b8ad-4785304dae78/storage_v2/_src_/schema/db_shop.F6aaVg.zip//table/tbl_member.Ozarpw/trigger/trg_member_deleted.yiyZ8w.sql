CREATE TRIGGER trg_member_deleted
  AFTER DELETE
  ON tbl_member
  FOR EACH ROW
  -- 각 행마다 작동하라고 지정
begin  
	-- 원본 테이블 OLD에서 삭제되는 니용을 로그로 남김
    insert into tbl_member_deleted values (
		OLD.id,
        OLD.name,
        OLD.address,
        curdate()
    );
end;

